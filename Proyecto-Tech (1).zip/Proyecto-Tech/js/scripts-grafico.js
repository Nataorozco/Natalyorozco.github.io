// --- Inicio de las variables de datos ---
const datosEnergia = {
    "energia_undimotriz": {
        "costo_mwh": 180,
        "factor_capacidad": 35,
        "emisiones_co2_ton_mwh": 0.005,
        "madurez_tecnologica": 2
    },
    "energia_solar_fotovoltaica": {
        "costo_mwh": 40,
        "factor_capacidad": 25,
        "emisiones_co2_ton_mwh": 0.003,
        "madurez_tecnologica": 4
    },
    "energia_eolica": {
        "costo_mwh": 35,
        "factor_capacidad": 40,
        "emisiones_co2_ton_mwh": 0.002,
        "madurez_tecnologica": 5
    },
    "energia_hidroelectrica": {
        "costo_mwh": 50,
        "factor_capacidad": 60,
        "emisiones_co2_ton_mwh": 0.001,
        "madurez_tecnologica": 5
    },
    "energia_combustibles_fosiles": {
        "costo_mwh": 70,
        "factor_capacidad": 80,
        "emisiones_co2_ton_mwh": 0.5,
        "madurez_tecnologica": 5
    }
};

const TiposEnergia = [
    'Energía Undimotriz',
    'Energía Solar Fotovoltaica',
    'Energía Eólica',
    'Energía Hidroeléctrica',
    'Combustibles Fósiles'
];

const Conjuntodedatos = [
    {
        label: 'Costo (USD/MWh)',
        data: [],
        backgroundColor: 'rgba(151, 255, 99, 0.6)',
        borderColor: 'rgb(159, 255, 99)',
        borderWidth: 1
    },
    {
        label: 'Factor de Capacidad (%)',
        data: [],
        backgroundColor: 'rgba(54, 235, 235, 0.6)',
        borderColor: 'rgb(54, 235, 223)',
        borderWidth: 1
    },
    {
        label: 'Emisiones CO2 (ton/MWh)',
        data: [],
        backgroundColor: 'rgba(2, 73, 195, 0.6)',
        borderColor: 'rgb(20, 0, 236)',
        borderWidth: 1
    },
    {
        label: 'Madurez Tecnológica (1-5)',
        data: [],
        backgroundColor: 'rgba(229, 102, 255, 0.6)',
        borderColor: 'rgb(229, 102, 255)',
        borderWidth: 1
    }
];

// Llenar los arrays de datos
for (const key of Object.keys(datosEnergia)) {
    Conjuntodedatos[0].data.push(datosEnergia[key].costo_mwh);
    Conjuntodedatos[1].data.push(datosEnergia[key].factor_capacidad);
    Conjuntodedatos[2].data.push(datosEnergia[key].emisiones_co2_ton_mwh);
    Conjuntodedatos[3].data.push(datosEnergia[key].madurez_tecnologica);
}

// --- Configuración global de Chart.js para el color de la fuente ---
// Cambia el color de todo el texto.
Chart.defaults.color = '#FFFFFF'; // Color blanco para toda la fuente por defecto
Chart.defaults.font.size = 14; // Opcional: ajusta el tamaño de la fuente si lo necesitas

// --- Inicio de la creación del gráfico ---

// --- Inicio de la creación del gráfico ---
const ctx = document.getElementById('GraficoBarra').getContext('2d');

let myChart; // La definimos aquí para que sea accesible globalmente o por otras funciones

function createOrUpdateChart() {
    if (myChart) {
        myChart.destroy(); // Destruye el gráfico existente si ya está creado
    }

    myChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: TiposEnergia,
            datasets: Conjuntodedatos
        },
        options: {
            responsive: true,
            plugins: {
                title: {
                    display: true,
                    text: 'Comparación de Métricas Clave por Tipo de Energía',
                    font: {
                        size: 18,
                        color: '#FFFFFF'
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            let label = context.dataset.label || '';
                            if (label) {
                                label += ': ';
                            }
                            if (context.datasetIndex === 0) { // Costo
                                label += `${context.raw} USD/MWh`;
                            } else if (context.datasetIndex === 1) { // Factor de Capacidad
                                label += `${context.raw}%`;
                            } else if (context.datasetIndex === 2) { // Emisiones CO2
                                label += `${context.raw.toFixed(4)} ton/MWh`;
                            } else if (context.datasetIndex === 3) { // Madurez Tecnológica
                                label += `${context.raw} (1-5)`;
                            }
                            return label;
                        }
                    },
                    titleColor: '#FFFFFF',
                    bodyColor: '#FFFFFF'
                },
                legend: {
                    // Importante: `onClick` DEBE estar fuera de `labels` para versiones recientes de Chart.js
                    // y debe manejar la lógica de visibilidad completamente.
                    onClick: function(e, legendItem, legend) {
                        const chart = legend.chart;
                        const clickedDatasetIndex = legendItem.datasetIndex;

                        // Determinar el nuevo estado de visibilidad del elemento clickeado.
                        // Si ya es el único visible, entonces hacemos todos visibles.
                        // Si no es el único visible, entonces solo este se hace visible.
                        let allHiddenExceptClicked = true;
                        chart.data.datasets.forEach((dataset, index) => {
                            if (index !== clickedDatasetIndex && chart.isDatasetVisible(index)) {
                                allHiddenExceptClicked = false;
                            }
                        });

                        if (allHiddenExceptClicked && chart.isDatasetVisible(clickedDatasetIndex)) {
                            // Si el elemento clickeado ya es el único visible, entonces mostramos todos.
                            chart.data.datasets.forEach((dataset, index) => {
                                chart.setDatasetVisibility(index, true);
                            });
                        } else {
                            // Si el elemento clickeado no es el único visible (o está oculto),
                            // entonces ocultamos todos excepto el clickeado.
                            chart.data.datasets.forEach((dataset, index) => {
                                const isVisible = (index === clickedDatasetIndex);
                                chart.setDatasetVisibility(index, isVisible);
                            });
                        }

                        chart.update(); // Actualiza la gráfica para reflejar los cambios
                    },
                    labels: {
                        fontColor: '#FFFFFF', // Asegura que el texto del label de la leyenda sea blanco
                        generateLabels: function(chart) {
                            const datasets = chart.data.datasets;
                            return datasets.map((dataset, i) => {
                                // Aquí puedes añadir lógica para el estilo de los labels de la leyenda
                                // cuando están ocultos/visibles, por ejemplo, atenuar el color.
                                const isVisible = chart.isDatasetVisible(i);
                                return {
                                    text: dataset.label,
                                    fillStyle: dataset.backgroundColor,
                                    strokeStyle: dataset.borderColor,
                                    lineWidth: dataset.borderWidth,
                                    // Esta propiedad controla si el ítem de la leyenda tiene un estilo "tachado"
                                    hidden: !isVisible,
                                    fontColor: isVisible ? '#FFFFFF' : 'rgba(255, 255, 255, 0.4)', // Atenúa el color del texto si está oculto
                                    datasetIndex: i // Importante para que `onClick` pueda identificar el dataset
                                };
                            });
                        }
                    }
                }
            },
            scales: {
                x: {
                    title: {
                        display: true,
                        text: 'Tipo de Energía',
                        color: 'rgb(151, 255, 99)'
                    },
                    ticks: {
                        color: '#FFFFFF'
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.2)'
                    }
                },
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Valor de la Métrica',
                        color:'rgb(151, 255, 99)'
                    },
                    ticks: {
                        color: '#FFFFFF'
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.2)'
                    }
                }
            }
        }
    });
}

document.addEventListener('DOMContentLoaded', createOrUpdateChart);